public enum State {
    START, MAIN, PAUSE;
}

